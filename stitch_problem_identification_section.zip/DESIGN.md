---
name: Oceanic Waste Exchange
colors:
  surface: '#101415'
  surface-dim: '#101415'
  surface-bright: '#363a3b'
  surface-container-lowest: '#0b0f10'
  surface-container-low: '#191c1d'
  surface-container: '#1d2021'
  surface-container-high: '#272a2c'
  surface-container-highest: '#323536'
  on-surface: '#e1e3e4'
  on-surface-variant: '#bec8cc'
  inverse-surface: '#e1e3e4'
  inverse-on-surface: '#2e3132'
  outline: '#889296'
  outline-variant: '#3e484b'
  surface-tint: '#7ed3e8'
  primary: '#7ed3e8'
  on-primary: '#003640'
  primary-container: '#127b8e'
  on-primary-container: '#e5f9ff'
  inverse-primary: '#006879'
  secondary: '#96d0df'
  on-secondary: '#003640'
  secondary-container: '#064e5b'
  on-secondary-container: '#85becd'
  tertiary: '#4ed8ec'
  on-tertiary: '#00363d'
  tertiary-container: '#007c8a'
  on-tertiary-container: '#e1faff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#a9edff'
  primary-fixed-dim: '#7ed3e8'
  on-primary-fixed: '#001f26'
  on-primary-fixed-variant: '#004e5b'
  secondary-fixed: '#b2ecfc'
  secondary-fixed-dim: '#96d0df'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#064e5b'
  tertiary-fixed: '#9af0ff'
  tertiary-fixed-dim: '#4ed8ec'
  on-tertiary-fixed: '#001f24'
  on-tertiary-fixed-variant: '#004f58'
  background: '#101415'
  on-background: '#e1e3e4'
  surface-variant: '#323536'
typography:
  headline-xl:
    fontFamily: Be Vietnam Pro
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-bold:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 1.5rem
  margin-mobile: 1rem
  section-padding: 5rem
---

## Brand & Style

The design system is rooted in the "Blue Economy," blending professional B2B exchange reliability with an organic, maritime-inspired aesthetic. It evokes a sense of deep-sea environmental stewardship through a combination of **Corporate Modern** structure and **Glassmorphism**.

The visual narrative focuses on sustainability and circularity. The target audience includes commercial fisheries, waste processors, and biotechnology manufacturers. The interface must feel expansive and fluid, utilizing immersive gradients and soft, translucent layers that mimic the clarity of water. Key characteristics include high-quality typography, circular organic imagery, and a sense of depth achieved through subtle blurs rather than harsh shadows.

## Colors

The palette is derived from oceanic depths, transitioning from surface turquoise to deep-sea teal. 

- **Primary & Secondary:** A range of deep teals and dark cyan tones used for immersive background gradients and primary brand actions.
- **Tertiary:** A bright turquoise used for highlights, accents, and interactive feedback states.
- **Neutral:** A high-clarity "Sea Foam" white is used for primary text and surfaces to ensure maximum legibility against dark oceanic backgrounds.
- **Surface Tints:** Use low-opacity versions of white (10-20%) for glassmorphic containers, allowing background gradients to bleed through.

## Typography

The typography system balances the friendly, approachable nature of **Be Vietnam Pro** for headlines with the clean, highly legible structure of **Plus Jakarta Sans** for functional copy.

Headlines should be set with tight letter spacing and heavy weights to create a "liquid" block effect. Body text uses generous line heights to maintain readability against textured or gradient backgrounds. Navigation and small labels leverage increased letter spacing and bold weights for clear information architecture.

## Layout & Spacing

This design system utilizes a **Fluid Grid** model with expansive margins to evoke the openness of the sea. 

- **Grid:** A 12-column system for desktop, collapsing to 4 columns for mobile. 
- **Rhythm:** An 8px base unit drives all spacing. 
- **Reflow:** Large hero elements use organic, asymmetrical positioning. On mobile, these elements should stack vertically, maintaining their circular masking and floating "bubble" indicators. 
- **Margins:** Horizontal margins are generous (minimum 64px on desktop) to keep content focused in the center of the viewport.

## Elevation & Depth

Depth is established through **Glassmorphism** and layering rather than traditional drop shadows.

- **The Sea Layer:** Backgrounds consist of deep radial gradients (`#064E5B` to `#127B8E`).
- **The Glass Layer:** Functional cards and secondary buttons use a white fill at 10-15% opacity with a `20px` backdrop blur and a `1px` semi-transparent white border.
- **The Surface Layer:** Primary call-to-action elements use solid white with high-contrast text, appearing to "float" above the water.
- **Floating Assets:** Product images are always contained in perfect circles with thin, glowing turquoise borders to simulate bubbles.

## Shapes

The shape language is strictly **organic and circular**. 

- **Primary UI:** Buttons, input fields, and tags use a pill-shaped (fully rounded) radius to eliminate sharp corners.
- **Imagery:** Photography must be masked within circles or smooth, wave-like blobs.
- **Dividers:** Section transitions should use SVG "Wave" masks rather than straight horizontal lines to maintain the maritime theme.

## Components

### Buttons
- **Primary:** Solid white background, deep teal text, pill-shaped. High-contrast and elevated.
- **Secondary:** Glassmorphic (blurred background) with a thin white stroke.
- **Icon Buttons:** Circular glass containers with centered white icons.

### Indicators (Data Bubbles)
Small, floating pill-shaped chips used to show weights or values. These should always have a subtle motion (float animation) and a glassmorphic background to appear weightless.

### Cards
Cards do not have distinct shadows. They are defined by their backdrop blur and a very subtle inner glow or border. Use padding of `2rem` to give content room to breathe.

### Input Fields
Pill-shaped with a glassmorphic fill. Placeholder text should be set in low-opacity white. Focus states should trigger a bright turquoise outer glow.

### Lists & Navigation
Navigation links use uppercase labels with wide tracking. Active states are indicated by a subtle turquoise dot or a wave-inspired underline.